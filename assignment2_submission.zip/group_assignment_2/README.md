# Group Assignment 2: Report

**Group members:** <Name 1> (<Roll No>), <Name 2> (<Roll No>), <Name 3> (<Roll No>) *(fill in before submitting)*

## Folder layout

```
problem1/smart_home_bn.py        code for Parts A-E
problem1/outputs_log.txt         full console output
problem1/outputs/*.png           network figure, error-vs-size plot
problem2/Domain.pddl, Problem.pddl, Problem_extended.pddl
problem2/planner.py              planner + plan validator
problem2/outputs_log.txt         full console output
problem2/outputs/                one file per (scenario, search configuration)
problem3/royal_archive_access.pl Prolog program
problem3/check_resolution.py     Python re-run of the same proof (see note)
problem3/expected_resolution_output.txt
```

## Things to know before you read the results

The sandbox we built this in had no access to package registries, so `pgmpy`, a PDDL planner (Fast Downward / pyperplan), VAL and SWI-Prolog could not be installed. We therefore:

* wrote the Bayesian-network machinery ourselves (exact inference by enumeration, d-separation, ancestral sampling, MLE and BDeu). The maths is the standard one, but it is not pgmpy.
* wrote a small STRIPS planner (greedy best-first, A\*, breadth-first) and a plan simulator. Plans are validated by our own simulator, not by VAL.
* wrote the Prolog file and **could not run it here**. `check_resolution.py` runs the same algorithm (same clause order, same literal selection) in Python and shows the proof it should print. **Run `swipl royal_archive_access.pl` yourselves and take the screenshot from that run.** If SWI-Prolog complains about anything, fix it before submitting.

Terminal screenshots also have to be taken on your own machine; the `.png` plots and `.txt` logs in the folders are real outputs from our runs.

---

## Problem 1: Smart home Bayesian network

### Part A: expert network (seed does not matter here, exact inference)

All CPT rows were checked in code and sum to 1. Structure: W→A, D→O, O→A, O→L, A→E, L→E (`outputs/network_structure.png`).

| Query | Value |
|---|---|
| Q1 P(E=High) | 0.580631 |
| Q2 P(E=High \| W=Hot) | 0.706266 |
| Q3 P(E=High \| D=Weekend) | 0.640199 |
| Q4 P(E=High \| W=Cold, O=High) | 0.484250 |
| Q5 P(W=Hot \| E=High) | 0.608188 |
| Q6 P(A=On \| E=High) | 0.692867 |
| Q7 P(A=On \| E=High, L=Heavy) | 0.649899 |

**Q6 vs Q7 (explaining away).** A and L are both parents of E. If we only know the energy use is high, the AC being on is a likely cause (0.693). Once we also know the appliance load is heavy, that is already a good explanation for the high reading, so the AC is needed less to explain it and the probability drops to 0.650. (A and L are also linked through Occupancy, which pushes the other way slightly, but the explaining-away effect wins.)

**Q1 by hand.** Marginalise Occupancy first:
P(O=High) = 0.7·0.45 + 0.3·0.80 = 0.555, P(O=Low) = 0.445.
P(A=On | O=High) = 0.5·0.9 + 0.3·0.4 + 0.2·0.1 = 0.59; P(A=On | O=Low) = 0.5·0.6 + 0.3·0.15 + 0.2·0.05 = 0.355.
Then P(E=High) = Σ_O Σ_A Σ_L P(O)·P(A|O)·P(L|O)·P(E=High|A,L):

| O | A | L | term |
|---|---|---|---|
| High | On | Heavy | 0.555·0.59·0.75·0.92 = 0.225941 |
| High | On | Light | 0.555·0.59·0.25·0.68 = 0.055667 |
| High | Off | Heavy | 0.555·0.41·0.75·0.55 = 0.093864 |
| High | Off | Light | 0.555·0.41·0.25·0.12 = 0.006826 |
| Low | On | Heavy | 0.445·0.355·0.35·0.92 = 0.050868 |
| Low | On | Light | 0.445·0.355·0.65·0.68 = 0.069825 |
| Low | Off | Heavy | 0.445·0.645·0.35·0.55 = 0.055252 |
| Low | Off | Light | 0.445·0.645·0.65·0.12 = 0.022388 |

Sum = **0.580631**, identical to the code.

### Part B: conditional independence

| Statement | d-separated? | Reason |
|---|---|---|
| W ⊥ D | Yes | Only path is W→A←O←D, blocked at the collider A (A and its descendant E are unobserved). |
| W ⊥ D \| E | **No** | Observing E (descendant of the collider A) opens the path W→A←O←D. |
| W ⊥ L \| O | Yes | Path W→A←O→L: A is a collider (unobserved, so blocked), and even if opened, O is observed on the fork, blocking it. |

Numerical checks: P(W=Hot)=P(W=Hot|D=Weekend)=0.5; P(W=Hot | E=High)=0.6082 ≠ P(W=Hot | E=High, D=Weekend)=0.5998 (dependent once E is observed); P(W=Hot | O=High)=P(W=Hot | O=High, L=Heavy)=0.5.

### Part C: synthetic data (seed = 42, own ancestral sampler)

Weather frequencies (true: 0.50 / 0.30 / 0.20):

| n | Hot | Mild | Cold |
|---|---|---|---|
| 500 | 0.510 | 0.286 | 0.204 |
| 5000 | 0.4992 | 0.3020 | 0.1988 |
| 20000 | 0.4953 | 0.3058 | 0.1989 |

(Weather, Occupancy) counts:

| (W, O) | 500 | 5000 | 20000 |
|---|---|---|---|
| Hot, High | 155 | 1402 | 5520 |
| Hot, Low | 100 | 1094 | 4386 |
| Mild, High | 75 | 823 | 3416 |
| Mild, Low | 68 | 687 | 2700 |
| Cold, High | 51 | 558 | 2228 |
| Cold, Low | 51 | 436 | 1750 |

### Parts D and E: learning and comparison

The AC CPT (expert vs MLE vs BDeu, ESS = 10) is printed for each size in `outputs_log.txt`. For n = 500, P(AC=On | Hot, High) is 0.90 (expert), 0.852 (MLE), 0.848 (BDeu).

**n = 500**

| Query | Expert | MLE | Bayesian | \|Diff\| MLE | \|Diff\| Bayes |
|---|---|---|---|---|---|
| Q1 | 0.5806 | 0.5570 | 0.5559 | 0.0237 | 0.0247 |
| Q2 | 0.7063 | 0.7050 | 0.6991 | 0.0013 | 0.0072 |
| Q3 | 0.6402 | 0.6092 | 0.6046 | 0.0310 | 0.0356 |
| Q4 | 0.4843 | 0.4203 | 0.4268 | 0.0639 | 0.0575 |
| Q5 | 0.6082 | 0.6455 | 0.6370 | 0.0373 | 0.0288 |
| Q6 | 0.6929 | 0.7280 | 0.7236 | 0.0351 | 0.0307 |
| Q7 | 0.6499 | 0.6584 | 0.6560 | 0.0085 | 0.0061 |

**n = 5000**

| Query | Expert | MLE | Bayesian | \|Diff\| MLE | \|Diff\| Bayes |
|---|---|---|---|---|---|
| Q1 | 0.5806 | 0.5794 | 0.5793 | 0.0012 | 0.0014 |
| Q2 | 0.7063 | 0.7034 | 0.7028 | 0.0029 | 0.0035 |
| Q3 | 0.6402 | 0.6399 | 0.6393 | 0.0003 | 0.0009 |
| Q4 | 0.4843 | 0.4860 | 0.4863 | 0.0017 | 0.0021 |
| Q5 | 0.6082 | 0.6060 | 0.6053 | 0.0022 | 0.0029 |
| Q6 | 0.6929 | 0.6884 | 0.6881 | 0.0044 | 0.0048 |
| Q7 | 0.6499 | 0.6496 | 0.6493 | 0.0003 | 0.0006 |

**n = 20000**

| Query | Expert | MLE | Bayesian | \|Diff\| MLE | \|Diff\| Bayes |
|---|---|---|---|---|---|
| Q1 | 0.5806 | 0.5768 | 0.5768 | 0.0038 | 0.0038 |
| Q2 | 0.7063 | 0.7028 | 0.7026 | 0.0035 | 0.0036 |
| Q3 | 0.6402 | 0.6381 | 0.6379 | 0.0021 | 0.0023 |
| Q4 | 0.4843 | 0.4838 | 0.4839 | 0.0004 | 0.0004 |
| Q5 | 0.6082 | 0.6035 | 0.6033 | 0.0047 | 0.0049 |
| Q6 | 0.6929 | 0.6922 | 0.6921 | 0.0007 | 0.0008 |
| Q7 | 0.6499 | 0.6499 | 0.6499 | 0.0001 | 0.0000 |

**Mean absolute difference (plot: `outputs/mad_vs_size.png`)**

| n | MLE | Bayesian |
|---|---|---|
| 500 | 0.02868 | 0.02722 |
| 5000 | 0.00187 | 0.00230 |
| 20000 | 0.00219 | 0.00226 |

**Largest error at n = 500.** Q4, P(E=High | W=Cold, O=High): 0.0639 for MLE (0.0575 for BDeu). Its evidence (Cold, High) appears in only 51 of the 500 rows (about 10%), so the CPT entries that Q4 relies on, especially P(AC | Cold, High), are estimated from very few rows and are noisy. The other queries condition on more common events (e.g. W=Hot, D=Weekend or E=High).

**Which estimator is better for small data?** At n = 500 the Bayesian estimator has a slightly lower mean error (0.0272 vs 0.0287). The BDeu pseudo-counts pull sparse rows toward uniform and prevent zero or extreme probabilities from rows with few samples, e.g. P(AC=On | Cold, Low) goes from 0.0196 (MLE) to 0.0348 (true value 0.05). At n = 5000 and 20000 the data swamp the prior and both are almost the same, with MLE marginally ahead; the prior is slightly wrong for CPT entries whose true value is far from 0.5. The gap at n = 500 is small and comes from a single random seed, so we would not claim more than "BDeu is a little safer on small data". The MLE error at 20000 is also slightly above its value at 5000, which is ordinary sampling noise; averaging over several seeds would smooth this out.

---

## Problem 2: Mars rover (PDDL)

`Domain.pddl` uses only `:strips` and `:typing`. Because negative preconditions are not allowed, rocks are tagged with static `soft` / `hard` predicates and there are two collect actions (`collect-soft`, `collect-hard` which needs `has-drill`). Two-way routes are two `connected` facts; SiteC→SiteD has only one.

### Search results

| Scenario | Configuration | Plan length (= number of actions) | States expanded | Time (s) |
|---|---|---|---|---|
| Original | Greedy best-first, h_add (satisficing) | 34 | 77 | 0.04 |
| Original | A\*, problem-specific admissible heuristic | **25** | 2,649 | 0.11 |
| Original | A\*, h_max | **25** | 171,879 | 50.6 |
| Original | Breadth-first | **25** | 332,519 | 6.0 |
| Extended | Greedy best-first, h_add | 61 | 721 | 0.38 |
| Extended | A\*, problem-specific admissible heuristic | **40** | 1,113,813 | 60.0 |
| Extended | A\*, h_max | not finished | stopped at 147,433 | 90 (budget) |
| Extended | Breadth-first | not finished | stopped at 2,758,945 (state cap) | 65.9 |

Plans are sequential, so "plan length" and "total number of actions" are the same number. (The grounded task has 162 actions for the original and 216 for the extended problem.) Times depend on the machine.

**Be aware:** for the extended scenario the optimal value 40 comes from A\* with our own heuristic (deposits + collects + pick-drill + a move lower bound; the action classes are disjoint, so the bounds add). Neither BFS nor A\*/h_max finished there, so 40 has not been confirmed independently. The heuristic was checked on the original problem (it returns 25, equal to BFS), and sanity-checked along both optimal plans, but that is not a formal proof of admissibility.

### Goal verification

Every plan was simulated step by step with the lifted actions from `Domain.pddl`. Each output file in `problem2/outputs/` shows the final state: all rocks at `base`, `bay1` and `bay2` empty, rover at `base` (drill held). All plans end with "Goal satisfied: True".

### Plan analysis

**1. Satisficing vs optimal.** Original: 34 vs 25 steps; extended: 61 vs 40. Greedy best-first follows the heuristic and stops at the first plan it finds without caring about its length. Its plans carry **one rock per trip** (it always uses bay1), so it walks to Base far more often. The optimal plans are shorter because they load both bays before returning.

**2. Storage bays and drill (original, optimal 25-step plan).** The rover goes Base→SiteB, collects Rock2 (bay1), continues to SiteD, collects Rock4 (bay2), and returns SiteD→SiteB→Base, depositing both (steps 1-8). It then goes Base→A→C→E and picks up the drill at SiteE in **step 12**, i.e. only once it passes SiteE, after the soft rocks are already delivered. It collects Rock5 at SiteF (bay1), returns to SiteC, collects Rock3 (bay2), and brings both home; Rock3 is deposited first, so bay2 is free to take Rock1 from SiteA on a short last trip. The final deposit (Rock5, step 25) frees bay1. Both bays are in use for most of the plan.

**3. Extended scenario.** With Base↔SiteB closed, SiteB can only be reached through SiteD. In the optimal plan the rover goes Base→A→C and then **uses the one-way slope C→D** (step 3) to get to SiteD, collects Rock4, goes D→B for Rock2, back B→D, then D→E (picks up the drill, step 9) and returns E→C→A→Base. The one-way route is therefore used once, in the downhill direction; the rover never needs to go from D to C, which is not allowed. Later trips use Base→A→C→E→F and back for the hard rocks, Rock6, Rock3 and Rock1.

---

## Problem 3: Royal archive (resolution refutation)

**Representation.** Predicates: `archivist/1, verifies/2, trusted/1, access/2, sealed/1, permitted/2, inspects/2, finds_mark/2, stored_in_archive/1`; constants `mira`, `scroll_7`; variables x (person), r (record).

1. ∀x∀r (archivist(x) ∧ verifies(x,r) → trusted(x))
2. ∀x∀r (trusted(x) ∧ access(x,r) ∧ sealed(r) → permitted(x,r))
3. ∀x∀r (inspects(x,r) ∧ finds_mark(x,r) → verifies(x,r))
4. ∀r (stored_in_archive(r) → sealed(r))
5. stored_in_archive(scroll_7)  6. access(mira, scroll_7)  7. inspects(mira, scroll_7) ∧ finds_mark(mira, scroll_7)  8. archivist(mira)

Goal: trusted(mira). **Negated goal:** ¬trusted(mira).

**Clause form** (no existential quantifiers, so no Skolemization is needed): variables standardized apart (x1,r1 / x2,r2 / x3,r3 / r4), implications removed, De Morgan applied, quantifiers dropped:

* C1: ¬archivist(X) ∨ ¬verifies(X,R) ∨ trusted(X)
* C2: ¬trusted(X) ∨ ¬access(X,R) ∨ ¬sealed(R) ∨ permitted(X,R)
* C3: ¬inspects(X,R) ∨ ¬finds_mark(X,R) ∨ verifies(X,R)
* C4: ¬stored_in_archive(R) ∨ sealed(R)
* C5: stored_in_archive(scroll_7); C6: access(mira,scroll_7); C7a: inspects(mira,scroll_7); C7b: finds_mark(mira,scroll_7); C8: archivist(mira)
* NG: ¬trusted(mira)

**Resolution** (see `expected_resolution_output.txt`):

1. NG with C1 → ¬archivist(mira) ∨ ¬verifies(mira,R)
2. with C3 → ¬archivist(mira) ∨ ¬inspects(mira,R) ∨ ¬finds_mark(mira,R)
3. with C7a (R = scroll_7) → ¬archivist(mira) ∨ ¬finds_mark(mira,scroll_7)
4. with C7b → ¬archivist(mira)
5. with C8 → **[]**

The empty clause is derived, so trusted(mira) follows. Rules 2 and 4 and facts 5 and 6 are not needed: they only lead to "permitted to inspect", which is a different thing from actually inspecting, and Mira's inspection is stated directly in fact 7.

In the Prolog program, steps 1-7 are stored in separate predicates (`fol/3`, `negated_goal/1`, `step3/2` ... `step6/2`, `clause_kb/2`) and printed one after another; step 8 is the resolution procedure (linear resolution from the negated goal with iterative deepening), which prints every resolvent. Stages 3-6 are written out by hand; only the clauses in `clause_kb/2` feed the proof.
